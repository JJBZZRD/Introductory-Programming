from DMS.__main__ import *
from DMS.DB.config import *


print("Hello World")