from .refugee import Refugee

print(Refugee.get_refugee(campID=2))
